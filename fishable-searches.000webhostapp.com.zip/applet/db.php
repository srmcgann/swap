<?php
	$db_user="id21284549_user";
	$db_pass="Chrome57253batch.sh";
	$db_host="localhost";
	$db="id21284549_videodemos2";
	$baseDomain="fishable-searches.000webhostapp.com";
	$appletDomain="fishable-searches.000webhostapp.com";
  $legacyDomain="legacy.cantelope.org";
	$baseURL   ="https://$baseDomain";
  $legacyURL ="https://$legacyDomain";
	$appletURL ="https://$appletDomain/applet";
	$link = mysqli_connect($db_host, $db_user, $db_pass, $db);
?>
